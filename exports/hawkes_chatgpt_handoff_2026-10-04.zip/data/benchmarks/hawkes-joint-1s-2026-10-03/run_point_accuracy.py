"""Parallel seed audits for an exact completed latent parameter set."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
workspace = root.parents[2]
sys.path.insert(0, str(workspace / 'ml'))
from hawkes_latent import LatentModel
from hawkes_latent_audit import audit
from hawkes_research import load_corpus, save_json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--model', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--particles', nargs='+', type=int, default=[128, 512, 2048])
parser.add_argument('--seeds', nargs='+', type=int, default=[71391, 91337])
args = parser.parse_args()
source = args.model.resolve()
value = json.loads(source.read_text())
model = LatentModel.deserialize(value['model'])
cache = root.parent / 'hawkes-resume-2026-10-03/counts-1s.npz'
corpus = load_corpus(cache, 3600)
binding = {'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
           'model': model.serialize(), 'corpus': corpus.identity,
           'cache_sha256': hashlib.sha256(cache.read_bytes()).hexdigest(),
           'particle_counts': args.particles, 'seeds': args.seeds,
           'source_sha256_by_module': {name: hashlib.sha256((workspace / 'ml' / name).read_bytes()).hexdigest()
             for name in ('hawkes_latent_audit.py', 'hawkes_latent.py', 'hawkes_modulation.py', 'hawkes_research.py')},
           'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'test_evaluated': False, 'refitting_performed': False,
           'purpose': 'Fixed completed-point numerical audit; not a final architecture selection'}
args.output.mkdir(parents=True, exist_ok=True)
path = args.output / 'source-bindings.json'
if path.exists():
    assert json.loads(path.read_text()) == binding
else:
    save_json(path, binding)
print(json.dumps({'model': str(source), 'particles': args.particles, 'seeds': args.seeds, 'workers': 2}), flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(audit, model, corpus, args.output / f'seed-{seed}', tuple(args.particles), (seed,))
               for seed in args.seeds]
    for future in futures:
        future.result()
rows, artifacts = [], []
for p in args.particles:
    for seed in args.seeds:
        path = args.output / f'seed-{seed}/particles-{p}-seed-{seed}.json'
        row = json.loads(path.read_text())
        assert row['particles'] == p and row['seed'] == seed and row['finite'] is True
        rows.append(row)
        artifacts.append({'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
save_json(args.output / 'review.json', {'binding': binding, 'rows': rows, 'artifacts': artifacts,
          'complete': True, 'final_selection_complete': False, 'test_evaluated': False})
print(json.dumps({'numerical_audit_complete': True, 'replicates': len(rows)}), flush=True)
