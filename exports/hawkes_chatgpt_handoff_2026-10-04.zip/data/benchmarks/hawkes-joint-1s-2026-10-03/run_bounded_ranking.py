"""Numerical reranking of a fixed, compute-budget-limited completed-fit pool."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import shutil
import sys
import time
import numpy as np
from scipy.special import gammaln

root = Path(__file__).resolve().parent
workspace = root.parents[2]
sys.path.insert(0, str(workspace / 'ml'))
from hawkes_latent import LatentModel, filter_model
from hawkes_latent_ranking import paired_interval
from hawkes_research import load_corpus, count_metrics, save_json

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

output = root / 'bounded-selection/ranking'
output.mkdir(exist_ok=True)
manifest_path = output.parent / 'completed-fit-pool.json'
manifest = json.loads(manifest_path.read_text())
cache = root.parent / 'hawkes-resume-2026-10-03/counts-1s.npz'
corpus = load_corpus(cache, 3600)
protocol = {'manifest_sha256': sha(manifest_path), 'cache_sha256': sha(cache),
            'corpus': corpus.identity, 'particle_counts': [128, 512],
            'seeds': [71391, 91337], 'workers': 6, 'test_evaluated': False,
            'code_sha256': {name: sha(workspace / 'ml' / name) for name in
                ('hawkes_latent.py', 'hawkes_modulation.py', 'hawkes_research.py',
                 'hawkes_latent_ranking.py')}, 'wrapper_sha256': sha(Path(__file__))}
protocol_path = output / 'protocol.json'
if protocol_path.exists():
    assert json.loads(protocol_path.read_text()) == protocol
else:
    save_json(protocol_path, protocol)
mask = corpus.score.copy()
mask[:corpus.train_end] = False
factorial = gammaln(corpus.y[mask] + 1).sum(axis=1)
for entry in manifest['shortlist']:
    source = Path(entry['source'])
    assert sha(source) == entry['source_sha256']
    assert json.loads(source.read_text())['model'] == entry['model']

def evaluate(job):
    entry, particles, seed = job
    key = entry['model_key']
    path = output / f'{key}-particles-{particles}-seed-{seed}.npz'
    metrics_path = path.with_suffix('.json')
    if path.exists() and metrics_path.exists():
        return json.loads(metrics_path.read_text())
    begin = time.monotonic()
    model = LatentModel.deserialize(entry['model'])
    result = filter_model(model, corpus.y, corpus.valid, corpus.initial_mean, particles, seed)
    loss = result[1]
    finite = bool(np.isfinite(loss[mask]).all())
    assert finite
    row = {'model_key': key, 'candidate': entry['candidate'], 'particles': particles,
           'seed': seed, 'finite': finite, 'seconds': time.monotonic() - begin,
           'validation_nll_without_factorial': float(loss[mask].mean()),
           'predictive_marginal_nll': float((loss[mask] + factorial).mean()),
           'joint_parameters': entry['joint_parameters'],
           'ess_mean_fraction': float(result[2][mask].mean() / particles),
           'ess_below_10pct_fraction': float(np.mean(result[2][mask] < .1 * particles)),
           **count_metrics(corpus.y[mask], result[0][mask])}
    row['selection_score'] = row['validation_nll_without_factorial'] + entry['joint_parameters'] / int(mask.sum())
    temporary = path.with_suffix('.writing')
    with temporary.open('wb') as stream:
        np.savez_compressed(stream, loss=loss, seconds=row['seconds'])
    os.replace(temporary, path)
    save_json(metrics_path, row)
    return row

jobs = [(e, p, s) for p in protocol['particle_counts'] for e in manifest['shortlist'] for s in protocol['seeds']]
print(json.dumps({'fixed_models': len(manifest['shortlist']), 'evaluations': len(jobs), 'workers': 6}), flush=True)
rows = []
with ThreadPoolExecutor(max_workers=6) as pool:
    for future in as_completed([pool.submit(evaluate, job) for job in jobs]):
        row = future.result()
        rows.append(row)
        print(json.dumps(row), flush=True)

ranking, comparisons, artifacts = [], [], []
for p in protocol['particle_counts']:
    for label, keys in manifest['family_shortlists'].items():
        scores = {key: float(np.mean([r['selection_score'] for r in rows if r['model_key'] == key and r['particles'] == p])) for key in keys}
        best = min(scores, key=scores.get)
        for key in keys:
            subset = [r for r in rows if r['model_key'] == key and r['particles'] == p]
            ranking.append({'family': label, 'model_key': key, 'particles': p,
                            'mean_selection_score': scores[key],
                            'mean_predictive_marginal_nll': float(np.mean([r['predictive_marginal_nll'] for r in subset])),
                            'selected_in_shortlist': key == best})
            for seed in protocol['seeds']:
                path = output / f'{key}-particles-{p}-seed-{seed}.npz'
                reference = output / f'{best}-particles-{p}-seed-{seed}.npz'
                with np.load(path, allow_pickle=False) as a, np.load(reference, allow_pickle=False) as b:
                    delta = a['loss'] - b['loss']
                comparisons.append({'family': label, 'model_key': key, 'reference': best,
                                    'particles': p, 'seed': seed,
                                    'validation_nll_delta': float(delta[mask].mean()),
                                    'paired_1h_block_interval95': paired_interval(delta, mask)})
for path in sorted(output.glob('*-particles-*')):
    artifacts.append({'path': str(path.resolve()), 'sha256': sha(path)})
save_json(output / 'review.json', {'protocol': protocol, 'rows': rows, 'ranking': ranking,
          'comparisons': comparisons, 'artifacts': artifacts, 'complete': True,
          'architecture_plateau_established': False, 'optimizer_convergence_established': False,
          'test_evaluated': False, 'interpretation': 'Fixed shortlist from completed joint fits. Conditional numerical comparisons exclude parameter and selection uncertainty.'})
print(json.dumps({'reranking_complete': True, 'ranking': ranking}), flush=True)
