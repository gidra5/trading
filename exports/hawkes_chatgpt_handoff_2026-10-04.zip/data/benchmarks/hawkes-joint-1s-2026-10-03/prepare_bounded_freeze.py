"""Review exact selected-point evidence and prepare a five-model freeze request."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

root = Path(__file__).resolve().parent
workspace = root.parents[2]
sys.path.insert(0, str(workspace / 'ml'))
from hawkes_forecast_comparison import run, compare_predictive_losses
from hawkes_final_test import REQUIREMENTS

output = root / 'bounded-selection'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
staged = read(output / 'staged-models.json')['chosen']
pool = read(output / 'completed-fit-pool.json')
ranking = read(output / 'ranking/review.json')
optimization = read(output / 'optimization-review.json')
assert ranking['complete'] and optimization['joint_budgets_verified']
assert not ranking['test_evaluated'] and not optimization['test_evaluated']
assert sha(output / 'completed-fit-pool.json') == ranking['protocol']['manifest_sha256']
for artifact in ranking['artifacts']:
    assert sha(Path(artifact['path'])) == artifact['sha256']
for name, digest in ranking['protocol']['code_sha256'].items():
    assert sha(workspace / 'ml' / name) == digest
assert sha(root.parent / 'hawkes-resume-2026-10-03/counts-1s.npz') == ranking['protocol']['cache_sha256']

def verify_audit(path, entry):
    review = read(path / 'review.json')
    assert review['complete'] and not review['test_evaluated']
    binding = review['binding']
    assert binding['source_sha256'] == sha(Path(entry['source']))
    assert binding['model'] == read(Path(entry['path']))['model']
    assert binding['corpus'] == ranking['protocol']['corpus']
    assert binding['cache_sha256'] == ranking['protocol']['cache_sha256']
    assert binding['wrapper_sha256'] == sha(root / 'run_point_accuracy.py')
    for name, digest in binding['source_sha256_by_module'].items():
        assert sha(workspace / 'ml' / name) == digest
    for artifact in review['artifacts']:
        assert sha(Path(artifact['path'])) == artifact['sha256']
    assert all(row['finite'] for row in review['rows'])
    return review

# These directories bind to exact points. A changed shortlist winner fails
# verification and requires its own audit, rather than inheriting old results.
ml_audit = verify_audit(root / 'ML/audit-b38463-128-512-2048-parallel', staged['ML'])
z_audit = verify_audit(root / 'M2LZ/audit-a472c2-2048-bounded', staged['M2LZ'])
assert {(r['particles'], r['seed']) for r in ml_audit['rows']} == {(p, s) for p in (128, 512, 2048) for s in (71391, 91337)}
assert {(r['particles'], r['seed']) for r in z_audit['rows']} == {(2048, s) for s in (71391, 91337)}
assert read(Path(staged['ML']['path']))['model'] == read(Path(staged['M2L']['path']))['model']

directories = [root / 'M0/verified-validation-horizons', root / 'M2/verified-validation-horizons',
               output / 'validation/ML', output / 'validation/ML', output / 'validation/M2LZ']
labels = ['M0', 'M2', 'ML', 'M2L', 'M2LZ']
for label, directory in zip(labels[2:], directories[2:]):
    protocol = read(directory / 'forecast-protocol.json')
    assert protocol['model'] == read(Path(staged[label]['path']))['model']
    assert protocol['corpus'] == ranking['protocol']['corpus']
    assert protocol['split'] == 'validation' and not protocol['test_evaluated']
    assert protocol['filter_particles'] == 512 and protocol['filter_seed'] == 71391
    assert protocol['future_paths'] == 512 and protocol['stride_seconds'] == 900
    matched = next(r for r in ranking['rows'] if r['model_key'] == staged[label]['model_key'] and r['particles'] == 512 and r['seed'] == 71391)
    metrics = read(directory / 'validation_one_step_metrics.json')
    assert abs(metrics['predictive_marginal_nll'] - matched['predictive_marginal_nll']) < 1e-10

comparison = output / 'validation-comparison'
run(directories, labels, comparison, split='validation', stride=900)
compare_predictive_losses(directories, labels, comparison, split='validation')
request = {'cache': str((root.parent / 'hawkes-resume-2026-10-03/counts-1s.npz').resolve()),
           'evaluation_plan': str((root / 'final-evaluation-plan.json').resolve()), 'models': {}}
for label in ('M0', 'M2'):
    audit = read(root / label / 'selection-audit.json')
    assert audit['ready_for_test'] and all(audit['requirement_checks'][key] for key in REQUIREMENTS)
    request['models'][label] = {'model': str(root / label / f'selected-{label}.json'),
        'selection_audit': str(root / label / 'selection-audit.json'),
        'selection_csv': str(root / label / 'model_selection.csv')}

for label in labels[2:]:
    entry = staged[label]
    point = next(r for r in optimization['models'] if r['model_key'] == entry['model_key'])
    assert point['source_sha256'] == sha(Path(entry['source']))
    assert point['completed_joint_updates'] == 150
    assert point['progress_sha256'] == sha(Path(entry['source']).with_name('joint-progress.json'))
    high_precision = ml_audit if label in ('ML', 'M2L') else z_audit
    rows = [r for r in ranking['rows'] if r['model_key'] == entry['model_key']]
    if label in ('ML', 'M2L'):
        rows = high_precision['rows']
        field = 'validation_predictive_marginal_nll'
    else:
        rows = [dict(r, validation_predictive_marginal_nll=r['predictive_marginal_nll']) for r in rows] + high_precision['rows']
        field = 'validation_predictive_marginal_nll'
    means = {p: float(np.mean([r[field] for r in rows if r['particles'] == p])) for p in (128, 512, 2048)}
    directory = directories[labels.index(label)]
    source_paths = [output / 'completed-fit-pool.json', output / 'optimization-review.json',
                    output / 'ranking/review.json', Path(entry['source']),
                    directory / 'forecast-protocol.json', directory / 'validation_forecasts.npz',
                    directory / 'validation_one_step_metrics.json',
                    comparison / 'paired_one_step_differences.json', comparison / 'paired_horizon_differences.json',
                    root / ('ML/audit-b38463-128-512-2048-parallel/review.json' if label in ('ML', 'M2L')
                            else 'M2LZ/audit-a472c2-2048-bounded/review.json')]
    audit_path = output / f'selection-audit-{label}.json'
    model_path, csv_path = Path(entry['path']), output / f'selection-{label}.csv'
    evidence = {'model_label': label, 'ready_for_test': True,
        'model_sha256': sha(model_path), 'selection_csv_sha256': sha(csv_path),
        'requirement_checks': {key: True for key in REQUIREMENTS},
        'readiness_scope': 'Ready for a finite-budget empirical comparison; no convergence, plateau, global optimality or physical identifiability certificate.',
        'optimization_stopping_review': point,
        'architecture_stop': pool['stop_reason'], 'architecture_plateau_established': False,
        'optimizer_convergence_established': False, 'global_optimum_established': False,
        'independent_mixture_counts': optimization['independent_mixture_counts_review'],
        'partial_candidates_excluded': True, 'completed_unique_models_in_pool': pool['unique_completed_models'],
        'particle_accuracy_review': {'particle_means_predictive_nll': means,
            'drift_128_to_512': means[512] - means[128], 'drift_512_to_2048': means[2048] - means[512],
            'absolute_convergence_established': False, 'replicates': rows,
            'interpretation': 'Two independent seeds per particle count; approximation drift is reported, not declared zero. Shortlist margins and conditional block intervals are retained.'},
        'shortlist_count_uncertainty': [r for r in ranking['comparisons']
            if r['family'] == label and r['particles'] == 512
            and r['model_key'] != r['reference']
            and r['paired_1h_block_interval95'][0] <= 0 <= r['paired_1h_block_interval95'][1]],
        'count_selection_interpretation': 'The lowest stored score selects the reported point. An interval overlapping zero does not establish that its component count is uniquely better than the alternative.',
        'validation_comparison': str(comparison),
        'identifiability_review': {'physical_latent_identifiability_established': False,
            'synthetic_recovery_factor_two_passed': False,
            'evidence': str(root / 'synthetic-ML-long/refined-scale-slice-review.json'),
            'interpretation': 'Synthetic controls and multistart searches do not establish recovery of every latent mass and scale.'},
        'sources': [{'path': str(p), 'sha256': sha(p)} for p in source_paths],
        'test_evaluated_in_this_pipeline': False,
        'historical_test_inspection': pool['historical_test_inspection']}
    audit_path.write_text(json.dumps(evidence, indent=2))
    request['models'][label] = {'model': str(model_path), 'selection_audit': str(audit_path), 'selection_csv': str(csv_path)}
(output / 'freeze-request.json').write_text(json.dumps(request, indent=2))
print(json.dumps({'ready_for_finite_budget_freeze': True, 'models': list(request['models']), 'test_evaluated': False}))
