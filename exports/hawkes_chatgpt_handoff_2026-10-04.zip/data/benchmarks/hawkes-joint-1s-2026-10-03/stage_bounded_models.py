"""Stage the empirically best completed models after matched-particle ranking."""
from pathlib import Path
import csv
import hashlib
import json

root = Path(__file__).resolve().parent
output = root / 'bounded-selection'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pool_path = output / 'completed-fit-pool.json'
pool = json.loads(pool_path.read_text())
ranking_path = output / 'ranking/review.json'
review = json.loads(ranking_path.read_text())
assert review['complete'] and not review['test_evaluated']
assert review['protocol']['manifest_sha256'] == sha(pool_path)
assert len(review['rows']) == len(pool['shortlist']) * 4
assert all(r['finite'] for r in review['rows'])
for artifact in review['artifacts']:
    assert sha(Path(artifact['path'])) == artifact['sha256']
entries = {e['model_key']: e for e in pool['shortlist']}
chosen = {}
for label in ('ML', 'M2L', 'M2LZ'):
    best = [r for r in review['ranking'] if r['family'] == label and r['selected_in_shortlist']]
    assert len(best) == 2
    assert len({r['model_key'] for r in best}) == 1, 'Particle-count ranking changed; review before staging.'
    entry = entries[best[0]['model_key']]
    source = Path(entry['source'])
    assert sha(source) == entry['source_sha256']
    assert json.loads(source.read_text())['model'] == entry['model']
    path = output / f'selected-{label}.json'
    value = {'model': entry['model'], 'model_label': label,
             'source_completed_fit': str(source), 'source_completed_fit_sha256': sha(source),
             'selection_criterion': 'Mean 512-particle validation NLL plus parameter count / scored validation seconds',
             'selected_entry': entry, 'stop_reason': pool['stop_reason'],
             'architecture_plateau_established': False, 'optimizer_convergence_established': False,
             'global_optimum_established': False, 'test_evaluated': False}
    if path.exists():
        assert json.loads(path.read_text()) == value
    else:
        path.write_text(json.dumps(value, indent=2))
    chosen[label] = {'path': str(path), 'source': str(source), 'candidate': entry['candidate'],
                     'model_key': entry['model_key'], 'joint_parameters': entry['joint_parameters']}
    with (output / 'completed-models.csv').open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    eligible = []
    for row in rows:
        model = json.loads(Path(row['source']).read_text())['model']
        if label == 'ML' and (model.get('anchors') or model.get('diffusions')):
            continue
        if label == 'M2L' and model.get('diffusions'):
            continue
        eligible.append(row)
    with (output / f'selection-{label}.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(eligible)
(output / 'staged-models.json').write_text(json.dumps({'chosen': chosen,
    'ranking_sha256': sha(ranking_path), 'test_evaluated': False,
    'ready_for_test': False, 'remaining': 'Exact selected-point numerical and validation horizon reviews.'}, indent=2))
print(json.dumps(chosen, indent=2))
