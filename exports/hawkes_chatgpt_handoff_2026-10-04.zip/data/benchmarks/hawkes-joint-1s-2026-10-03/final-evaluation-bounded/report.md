# Hawkes five-model experiment

Retain: M0, M2, M2LZ.

M2 is the leading mean-forecast candidate: final one-second total MAE is 9.8023 versus M0's 9.8460, and hour-ahead MAE is 13191.45 versus 15292.94, a 13.74% reduction. The conditional paired hour-MAE difference is -2101.49 with 95% interval [-4035.16, -468.26]. Hour R2 is nearly equal (0.43655 versus 0.43510), without an established R2 increase. Retain M0 as the simpler globally bounded baseline and fallback. Retain M2LZ for short-horizon density research: marginal one-second NLL is 4.28582 versus M2's 14.47588, but its mean forecasts are worse (one-second MAE 11.6614; hour MAE 25353.50, R2 -0.03780). Its nominal-90% hour intervals cover only 22.11%, so the likelihood win does not justify using its hour forecasts or intervals as reliable predictions. ML and M2L are identical at the selected point and both have poor hour forecasts (MAE 38202.20, R2 -0.71625); retain neither as a separate candidate.

## Evidence and limits

The experiment used one-second BTCUSDT buy/sell counts from August 17-30, 2026, with chronological training/validation/evaluation regions, coverage masks and post-gap warmup. All five final models were frozen before this pipeline evaluated the last region: 181609 scored seconds and 190 matched forecast origins, at horizons 1, 5, 15, 60, 300, 900 and 3600 seconds. Final filtering uses 512 particles and future simulation uses 2048 paths. All recorded simulated final origins completed without numerical failures. The architecture search was capped after the user rejected a multi-day runtime: 975 completed latent-search fit records represent 673 distinct fitted parameter sets; reused records are not independent restarts. Every shortlisted latent fit completed 150 joint updates with all retained coordinates free, but mathematical optimizer convergence and a forward/backward architecture plateau are not established. These are the best found parameter sets within the completed search, not globally optimal counts or scales. The selected latent mixtures have 20 modes for ML/M2L and 14 modes plus three OU components for M2LZ. A 13-mode M2LZ alternative is statistically close, so the selected count is not uniquely established. Exact-point audits used two seeds at 128, 512 and 2048 particles: ML NLL changes by -0.000000535 from 512 to 2048; M2LZ changes by -0.002121838. Absolute particle convergence is not claimed; approximation drift is tiny relative to the family likelihood margins but material for close count comparisons. Conditional block intervals exclude parameter, selection, filtering and simulation uncertainty, with no multiplicity adjustment. M2's validation hour-MAE advantage was not established and its validation hour R2 was lower than M0's, so its final-period MAE win should not be treated as universal across regimes. M2 has unbounded positive amplitude modulation without a global branching/stability certificate; no-failure finite forecasts do not certify unattended operation. M0 supplies the bounded baseline. Synthetic latent recovery failed the factor-two criterion for a weak hidden edge, and its scale slice was weakly identified; hidden L is a statistical component without established physical identity. Historical original-chat exploration inspected this evaluation period, so it is not a pristine untouched test. This study evaluates event-count predictions; it does not establish trading profitability.

All parameters were frozen before this evaluation. The fitted values below are the best found under the documented searches; they do not prove a global optimum. A latent channel is an inferred statistical component, without an established physical interpretation.

Historical test inspection: Original chat and exploratory 5-second runs inspected this chronological period; it is not a pristine holdout.

Test filtering uses 512 particles and simulated forecasts use 2048 future paths, at 900 second origin spacing.

## One-step test accuracy

NLL includes factorial constants and integrates latent states for the latent models. MAE and R² use the predictive mean for total buy-plus-sell counts.

| Model | Marginal NLL | Total MAE | Total R² | Buy MAE | Sell MAE |
| --- | --- | --- | --- | --- | --- |
| M0 | 14.497927 | 9.8460342 | 0.16648828 | 5.6393321 | 5.8331291 |
| M2 | 14.475881 | 9.8022593 | 0.16815096 | 5.6273048 | 5.8007837 |
| ML | 7.7074856 | 10.973547 | 0.1526406 | 6.2505847 | 6.461998 |
| M2L | 7.7074856 | 10.973547 | 0.1526406 | 6.2505847 | 6.461998 |
| M2LZ | 4.2858249 | 11.661426 | 0.1066571 | 6.8278985 | 6.3123788 |

## Paired one-step likelihood differences

Candidate minus reference marginal NLL; negative values favor the candidate. Pointwise 95% intervals resample contiguous scored-second blocks and stop at coverage gaps. They exclude parameter, selection and filtering uncertainty and have no multiplicity adjustment.

| Reference | Candidate | Scored seconds | NLL change | 95% interval |
| --- | --- | --- | --- | --- |
| M0 | M2 | 181609 | -0.022045898 | -0.035324863, -0.011017575 |
| M0 | ML | 181609 | -6.7904411 | -9.3641354, -4.1899267 |
| M0 | M2L | 181609 | -6.7904411 | -9.3641354, -4.1899267 |
| M0 | M2LZ | 181609 | -10.212102 | -14.340592, -6.2280822 |
| M2 | ML | 181609 | -6.7683952 | -9.3378338, -4.1717928 |
| M2 | M2L | 181609 | -6.7683952 | -9.3378338, -4.1717928 |
| M2 | M2LZ | 181609 | -10.190056 | -14.304259, -6.2102075 |
| ML | M2L | 181609 | 0 | 0, 0 |
| ML | M2LZ | 181609 | -3.4216607 | -5.0242501, -2.0175448 |
| M2L | M2LZ | 181609 | -3.4216607 | -5.0242501, -2.0175448 |

## Open-loop test forecasts

Forecasts do not use future observations. A failed origin makes aggregate point accuracy unavailable; results do not condition on surviving paths. Horizon log scores are Poisson scores at the forecast mean, not exact multistep marginal likelihoods.

### M0

| Horizon (s) | Origins | Total MAE | Total R² | Correlation | Path MC SE | Failed origins | 90% coverage, available origins | Poisson mean log score |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 190 | 13.644939 | 0.21717788 | 0.49015867 | N/A | 0 | N/A | 21.80875 |
| 5 | 190 | 47.796699 | 0.2726783 | 0.55349666 | N/A | 0 | N/A | 56.29756 |
| 15 | 190 | 107.56799 | 0.3345202 | 0.62141116 | N/A | 0 | N/A | 94.94604 |
| 60 | 190 | 247.98149 | 0.56754845 | 0.78620548 | N/A | 0 | N/A | 129.36167 |
| 300 | 190 | 1067.0847 | 0.59216523 | 0.80413417 | N/A | 0 | N/A | 401.43884 |
| 900 | 190 | 3128.3611 | 0.59803533 | 0.79473568 | N/A | 0 | N/A | 906.7678 |
| 3600 | 190 | 15292.942 | 0.4351006 | 0.68541591 | N/A | 0 | N/A | 4923.0574 |

### M2

| Horizon (s) | Origins | Total MAE | Total R² | Correlation | Path MC SE | Failed origins | 90% coverage, available origins | Poisson mean log score |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 190 | 13.598969 | 0.21624135 | 0.49057178 | N/A | 0 | N/A | 21.818576 |
| 5 | 190 | 47.625376 | 0.27274725 | 0.55614427 | N/A | 0 | N/A | 56.403158 |
| 15 | 190 | 106.74329 | 0.33105105 | 0.62094092 | N/A | 0 | N/A | 95.179862 |
| 60 | 190 | 244.85093 | 0.55800029 | 0.78031526 | N/A | 0 | N/A | 130.32737 |
| 300 | 190 | 1046.3681 | 0.57972569 | 0.79399993 | N/A | 0 | N/A | 407.36415 |
| 900 | 190 | 2895.1529 | 0.5924823 | 0.78201509 | N/A | 0 | N/A | 862.08413 |
| 3600 | 190 | 13191.453 | 0.43654643 | 0.66488484 | N/A | 0 | N/A | 4550.9944 |

### ML

| Horizon (s) | Origins | Total MAE | Total R² | Correlation | Path MC SE | Failed origins | 90% coverage, available origins | Poisson mean log score |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 190 | 14.160581 | 0.22462703 | 0.50642096 | 0.1454067 | 0 | 0.86315789 | 21.625969 |
| 5 | 190 | 50.612242 | 0.25219536 | 0.51703221 | 0.38109067 | 0 | 0.78947368 | 59.866249 |
| 15 | 190 | 120.90118 | 0.34082858 | 0.6119861 | 0.81823258 | 0 | 0.75263158 | 105.02294 |
| 60 | 190 | 352.02463 | 0.55221589 | 0.80458368 | 2.6177817 | 0 | 0.54210526 | 177.31253 |
| 300 | 190 | 2327.1032 | 0.33804397 | 0.85072458 | 11.472275 | 0 | 0.24210526 | 952.59627 |
| 900 | 190 | 8448.3357 | -0.15135842 | 0.84474174 | 27.182256 | 0 | 0.15263158 | 3648.1379 |
| 3600 | 190 | 38202.2 | -0.71625419 | 0.59585508 | 64.187808 | 0 | 0.047368421 | 16380.914 |

### M2L

| Horizon (s) | Origins | Total MAE | Total R² | Correlation | Path MC SE | Failed origins | 90% coverage, available origins | Poisson mean log score |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 190 | 14.160581 | 0.22462703 | 0.50642096 | 0.1454067 | 0 | 0.86315789 | 21.625969 |
| 5 | 190 | 50.612242 | 0.25219536 | 0.51703221 | 0.38109067 | 0 | 0.78947368 | 59.866249 |
| 15 | 190 | 120.90118 | 0.34082858 | 0.6119861 | 0.81823258 | 0 | 0.75263158 | 105.02294 |
| 60 | 190 | 352.02463 | 0.55221589 | 0.80458368 | 2.6177817 | 0 | 0.54210526 | 177.31253 |
| 300 | 190 | 2327.1032 | 0.33804397 | 0.85072458 | 11.472275 | 0 | 0.24210526 | 952.59627 |
| 900 | 190 | 8448.3357 | -0.15135842 | 0.84474174 | 27.182256 | 0 | 0.15263158 | 3648.1379 |
| 3600 | 190 | 38202.2 | -0.71625419 | 0.59585508 | 64.187808 | 0 | 0.047368421 | 16380.914 |

### M2LZ

| Horizon (s) | Origins | Total MAE | Total R² | Correlation | Path MC SE | Failed origins | 90% coverage, available origins | Poisson mean log score |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 190 | 15.599729 | 0.19518085 | 0.44294915 | 0.78218968 | 0 | 0.94210526 | 22.806781 |
| 5 | 190 | 54.132343 | 0.22074842 | 0.47462434 | 2.3147998 | 0 | 0.92105263 | 60.951766 |
| 15 | 190 | 130.58565 | 0.21912147 | 0.47285681 | 4.3720579 | 0 | 0.91578947 | 113.36833 |
| 60 | 190 | 374.694 | 0.34666049 | 0.59775548 | 9.4981258 | 0 | 0.82105263 | 210.53178 |
| 300 | 190 | 1872.9665 | 0.33818107 | 0.6685253 | 25.818137 | 0 | 0.66315789 | 817.85729 |
| 900 | 190 | 5985.4138 | 0.16786236 | 0.69951517 | 53.117091 | 0 | 0.45789474 | 2503.989 |
| 3600 | 190 | 25353.497 | -0.037803705 | 0.60273728 | 118.92483 | 0 | 0.22105263 | 10505.14 |

## Paired one-hour differences

Differences are candidate minus reference. Fixed contiguous blocks stop at coverage gaps. These 95% sampling intervals are conditional on stored fits and forecast means; they exclude parameter, model-selection, filtering and future-path Monte Carlo uncertainty.

| Reference | Candidate | MAE change | MAE 95% interval | R² change | R² 95% interval |
| --- | --- | --- | --- | --- | --- |
| M0 | M2 | -2101.4892 | -4035.1588, -468.26204 | 0.0014458288 | -0.047555286, 0.58625024 |
| M0 | ML | 22909.258 | 15561.758, 29936.995 | -1.1513548 | -13.86478, -0.329313 |
| M0 | M2L | 22909.258 | 15561.758, 29936.995 | -1.1513548 | -13.86478, -0.329313 |
| M0 | M2LZ | 10060.554 | 6109.8965, 14361.232 | -0.47290431 | -4.3098153, -0.28362872 |
| M2 | ML | 25010.747 | 16225.824, 33764.588 | -1.1528006 | -14.442126, -0.28353759 |
| M2 | M2L | 25010.747 | 16225.824, 33764.588 | -1.1528006 | -14.442126, -0.28353759 |
| M2 | M2LZ | 12162.044 | 6905.3571, 18164.848 | -0.47435014 | -4.9230893, -0.23902283 |
| ML | M2L | 0 | 0, 0 | 0 | 0, 0 |
| ML | M2LZ | -12848.703 | -17814.901, -6334.5868 | 0.67845049 | 0.029001898, 9.4907548 |
| M2L | M2LZ | -12848.703 | -17814.901, -6334.5868 | 0.67845049 | 0.029001898, 9.4907548 |

![Test horizon comparison](comparison/horizon_comparison.png)

## Stability and inferred hidden states

| Model | Branching radius | Global bound | Hour failed origins |
| --- | --- | --- | --- |
| M0 | 0.95 | True | 0 |
| M2 | 0.95 | False | 0 |
| ML | 0.90373805 | True | 0 |
| M2L | 0.90373805 | True | 0 |
| M2LZ | 0.22859647 | True | 0 |

A linear-core radius below one is not a global stability guarantee for unbounded positive amplitude modulation. OU immigration is exogenous. Its loadings have arbitrary common signs, and equal-timescale components may be rotated without changing their covariance.

| Model | Mean filtered L rate | Mean previous L count | Mean active probability | Fraction active probability > 0.01 | Physical identity established |
| --- | --- | --- | --- | --- | --- |
| ML | 0.39770568 | 0.31091538 | 0.1526376 | 0.17837772 | False |
| M2L | 0.39770568 | 0.31091538 | 0.1526376 | 0.17837772 | False |
| M2LZ | 0.012837965 | 0.013284248 | 0.012786537 | 0.04510239 | False |

Filtered hidden estimates incorporate observations through the current bin. Correlations with current observed counts are descriptive inference diagnostics, not causal forecasting scores. Subsecond decay estimates belong to a one-second count model; they do not establish event-time resolution.

![Inferred latent states](latent_states.png)

## All fitted parameters

B means buy, S sell, and L the hidden event channel. Each source→target edge has its own exponential count and continuous decay scales. Integrated mass is offspring per source event for the linear core. Background rates are counts per second; decay scales are seconds. Modulation coefficients and OU loadings are dimensionless.

| Model | B→B count | S→B count | L→B count | B→S count | S→S count | L→S count | B→L count | S→L count | L→L count |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M0 | 5 | 2 | N/A | 1 | 5 | N/A | N/A | N/A | N/A |
| M2 | 5 | 2 | N/A | 3 | 5 | N/A | N/A | N/A | N/A |
| ML | 5 | 3 | 1 | 1 | 6 | 1 | 1 | 1 | 1 |
| M2L | 5 | 3 | 1 | 1 | 6 | 1 | 1 | 1 | 1 |
| M2LZ | 4 | 1 | 1 | 1 | 4 | 1 | 1 | 0 | 1 |

### M0

Background

| target | value |
| --- | --- |
| B | 0.31118676 |
| S | 0.31006326 |

Exponential

| target | source | mode_index | integrated_mass | tau_seconds |
| --- | --- | --- | --- | --- |
| B | B | 0 | 0.14093719 | 0.39900558 |
| B | B | 1 | 0.23525651 | 3.0530082 |
| B | B | 2 | 0.16855998 | 27.149836 |
| B | B | 3 | 0.12909903 | 119.10049 |
| B | B | 4 | 0.14408274 | 980.65551 |
| B | S | 5 | 0.12235195 | 36.868763 |
| B | S | 6 | 0.023018824 | 7556.882 |
| S | B | 7 | 0.15526135 | 33.520406 |
| S | S | 8 | 0.16169603 | 0.48591996 |
| S | S | 9 | 0.21702133 | 3.7037446 |
| S | S | 10 | 0.17456963 | 28.027662 |
| S | S | 11 | 0.15072619 | 272.96158 |
| S | S | 12 | 0.075082042 | 1958.2283 |

Full precision model: [M0/frozen-model.json](M0/frozen-model.json). Selection review: [M0/selection-audit.json](M0/selection-audit.json). Architecture history: [M0/architecture-selection.csv](M0/architecture-selection.csv).

### M2

Background

| target | value |
| --- | --- |
| B | 0.14349947 |
| S | 0.25636285 |

Exponential

| target | source | mode_index | integrated_mass | tau_seconds |
| --- | --- | --- | --- | --- |
| B | B | 0 | 0.13590465 | 0.40555133 |
| B | B | 1 | 0.21886657 | 3.1354594 |
| B | B | 2 | 0.17018038 | 30.357408 |
| B | B | 3 | 0.11922823 | 120.06247 |
| B | B | 4 | 0.15867136 | 933.39311 |
| B | S | 5 | 0.12292473 | 43.044672 |
| B | S | 6 | 0.051678193 | 12781.849 |
| S | B | 7 | 0.0013628285 | 0.10936978 |
| S | B | 8 | 0.12884427 | 62.335022 |
| S | B | 9 | 0.017932179 | 371.59491 |
| S | S | 10 | 0.14894067 | 0.47849957 |
| S | S | 11 | 0.20743302 | 3.5754202 |
| S | S | 12 | 0.19759521 | 30.377296 |
| S | S | 13 | 0.14415259 | 388.42992 |
| S | S | 14 | 0.07610031 | 3103.7091 |

Anchor

| source | tau_seconds | anchor_index |
| --- | --- | --- |
| B | 2.8287544 | 0 |
| S | 1.1188194 | 1 |
| S | 35.786617 | 2 |

Modulation

| value | mode_index | anchor_index | gate | coefficient_on_normalized_slow | normalization_reference_mean | link | coefficient_on_raw_slow |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0.025698589 | 0 | 0 | 0.9024017 | 0.023190451 | 8.3757241 | linear | 0.0027687697 |
| 0.042855234 | 0 | 1 | 0.18451534 | 0.0079074479 | 7.6492309 | linear | 0.0010337572 |
| 1.4524615e-17 | 0 | 2 | 0.99999578 | 1.4524553e-17 | 7.6492309 | linear | 1.8988253e-18 |
| 0 | 1 | 0 | 0.0025811535 | 0 | 8.3757241 | linear | 0 |
| 1.1689722e-18 | 1 | 1 | 6.3323916e-05 | 7.4023897e-23 | 7.6492309 | linear | 9.6772993e-24 |
| 0 | 1 | 2 | 0.98513861 | 0 | 7.6492309 | linear | 0 |
| 0.47627044 | 2 | 0 | 2.9449783e-07 | 1.4026061e-07 | 8.3757241 | linear | 1.6746088e-08 |
| 1.7220604 | 2 | 1 | 7.2067792e-09 | 1.2410509e-08 | 7.6492309 | linear | 1.6224519e-09 |
| 0 | 2 | 2 | 0.0074872089 | 0 | 7.6492309 | linear | 0 |
| 0.099021303 | 3 | 0 | 1.2036823e-09 | 1.1919019e-10 | 8.3757241 | linear | 1.4230434e-11 |
| 0.015335818 | 3 | 1 | 2.9455803e-11 | 4.5172883e-13 | 7.6492309 | linear | 5.9055458e-14 |
| 0.094382623 | 3 | 2 | 3.0831886e-05 | 2.9099943e-06 | 7.6492309 | linear | 3.8042966e-07 |
| 0.099999858 | 4 | 0 | 3.2952064e-13 | 3.2952018e-14 | 8.3757241 | linear | 3.9342291e-15 |
| 0.099982625 | 4 | 1 | 8.0638349e-15 | 8.0624338e-16 | 7.6492309 | linear | 1.0540189e-16 |
| 0.099934757 | 4 | 2 | 8.4408123e-09 | 8.4353052e-10 | 7.6492309 | linear | 1.1027651e-10 |
| 0.29124602 | 5 | 0 | 7.2855667e-08 | 2.1218923e-08 | 8.3757241 | linear | 2.5333838e-09 |
| 0.80282245 | 5 | 1 | 1.7828811e-09 | 1.431337e-09 | 7.6492309 | linear | 1.8712168e-10 |
| 0 | 5 | 2 | 0.0018627529 | 0 | 7.6492309 | linear | 0 |
| 0.1 | 6 | 0 | 9.3705749e-18 | 9.3705749e-19 | 8.3757241 | linear | 1.1187779e-19 |
| 0.1 | 6 | 1 | 2.2931118e-19 | 2.2931118e-20 | 7.6492309 | linear | 2.9978332e-21 |
| 0.1 | 6 | 2 | 2.4003129e-13 | 2.4003129e-14 | 7.6492309 | linear | 3.1379793e-15 |
| 3 | 7 | 0 | 0.99942826 | 2.9982848 | 8.3757241 | linear | 0.3579732 |
| 0 | 7 | 1 | 0.97715697 | 0 | 7.6492309 | linear | 0 |
| 1.7509942e-18 | 7 | 2 | 0.99999998 | 1.7509941e-18 | 7.6492309 | linear | 2.2891114e-19 |
| 0.043319926 | 8 | 0 | 1.6565803e-08 | 7.1762937e-10 | 8.3757241 | linear | 8.5679681e-11 |
| 2.9999933 | 8 | 1 | 4.0538858e-10 | 1.216163e-09 | 7.6492309 | linear | 1.5899154e-10 |
| 0 | 8 | 2 | 0.00042416016 | 0 | 7.6492309 | linear | 0 |
| 0.099995655 | 9 | 0 | 1.3117829e-11 | 1.3117259e-12 | 8.3757241 | linear | 1.5661044e-13 |
| 0.099999854 | 9 | 1 | 3.2101177e-13 | 3.2101131e-14 | 7.6492309 | linear | 4.1966481e-15 |
| 0.041748756 | 9 | 2 | 3.3601869e-07 | 1.4028362e-08 | 7.6492309 | linear | 1.8339572e-09 |
| 0.0063240374 | 10 | 0 | 0.82672158 | 0.0052282182 | 8.3757241 | linear | 0.00062421088 |
| 2.8043969e-18 | 10 | 1 | 0.10454808 | 2.9319431e-19 | 7.6492309 | linear | 3.8329907e-20 |
| 0.010631516 | 10 | 2 | 0.99999182 | 0.010631429 | 7.6492309 | linear | 0.001389869 |
| 0 | 11 | 0 | 0.0015281587 | 0 | 8.3757241 | linear | 0 |
| 0 | 11 | 1 | 3.7452032e-05 | 0 | 7.6492309 | linear | 0 |
| 9.4121834e-18 | 11 | 2 | 0.97512707 | 9.1780748e-18 | 7.6492309 | linear | 1.199869e-18 |
| 0.24796741 | 12 | 0 | 2.9372738e-07 | 7.2834818e-08 | 8.3757241 | linear | 8.6959428e-09 |
| 0.18504859 | 12 | 1 | 7.1879253e-09 | 1.3301155e-09 | 7.6492309 | linear | 1.7388878e-10 |
| 0 | 12 | 2 | 0.0074677676 | 0 | 7.6492309 | linear | 0 |
| 0.099986145 | 13 | 0 | 1.0987283e-11 | 1.0985761e-12 | 8.3757241 | linear | 1.3116192e-13 |
| 0.099334451 | 13 | 1 | 2.6887431e-13 | 2.6708482e-14 | 7.6492309 | linear | 3.4916558e-15 |
| 0.098515307 | 13 | 2 | 2.8144387e-07 | 2.772653e-08 | 7.6492309 | linear | 3.6247474e-09 |
| 0.099999997 | 14 | 0 | 2.6953609e-15 | 2.6953608e-16 | 8.3757241 | linear | 3.218063e-17 |
| 0.099999915 | 14 | 1 | 6.5959283e-17 | 6.5959227e-18 | 7.6492309 | linear | 8.622988e-19 |
| 0.099999836 | 14 | 2 | 6.9042824e-11 | 6.904271e-12 | 7.6492309 | linear | 9.0260983e-13 |

Full precision model: [M2/frozen-model.json](M2/frozen-model.json). Selection review: [M2/selection-audit.json](M2/selection-audit.json). Architecture history: [M2/architecture-selection.csv](M2/architecture-selection.csv).

### ML

Background

| target | value |
| --- | --- |
| B | 0.082609299 |
| S | 0.30627877 |
| L | 0.1146334 |

Exponential

| target | source | mode_index | integrated_mass | tau_seconds |
| --- | --- | --- | --- | --- |
| B | B | 0 | 0.051189205 | 0.24572688 |
| B | B | 1 | 0.026155202 | 6.1844136 |
| B | B | 2 | 0.026047874 | 17.700898 |
| B | B | 3 | 0.0069339639 | 273.81504 |
| B | S | 4 | 0.03888758 | 165.89593 |
| B | S | 5 | 0.035124462 | 47379.824 |
| S | B | 6 | 0.019678711 | 110.55023 |
| S | S | 7 | 0.018598553 | 0.16183814 |
| S | S | 8 | 0.0061252607 | 1.9282045 |
| S | S | 9 | 0.092501898 | 47.746004 |
| S | S | 10 | 0.010166254 | 340.54984 |
| S | S | 11 | 0.024868342 | 314.88867 |
| S | L | 12 | 11.12929 | 0.16978283 |
| L | B | 13 | 0.013143006 | 46.296126 |
| L | S | 14 | 0.037070102 | 14.476478 |
| S | S | 15 | 0.0083698983 | 8985.8594 |
| B | L | 16 | 10.712111 | 0.13125843 |
| B | S | 17 | 0.058655804 | 14933.051 |
| L | L | 18 | 0.10420791 | 2.1521405 |
| B | B | 19 | 0.055808166 | 1.0268669 |

Full precision model: [ML/frozen-model.json](ML/frozen-model.json). Selection review: [ML/selection-audit.json](ML/selection-audit.json). Architecture history: [ML/architecture-selection.csv](ML/architecture-selection.csv).

### M2L

Background

| target | value |
| --- | --- |
| B | 0.082609299 |
| S | 0.30627877 |
| L | 0.1146334 |

Exponential

| target | source | mode_index | integrated_mass | tau_seconds |
| --- | --- | --- | --- | --- |
| B | B | 0 | 0.051189205 | 0.24572688 |
| B | B | 1 | 0.026155202 | 6.1844136 |
| B | B | 2 | 0.026047874 | 17.700898 |
| B | B | 3 | 0.0069339639 | 273.81504 |
| B | S | 4 | 0.03888758 | 165.89593 |
| B | S | 5 | 0.035124462 | 47379.824 |
| S | B | 6 | 0.019678711 | 110.55023 |
| S | S | 7 | 0.018598553 | 0.16183814 |
| S | S | 8 | 0.0061252607 | 1.9282045 |
| S | S | 9 | 0.092501898 | 47.746004 |
| S | S | 10 | 0.010166254 | 340.54984 |
| S | S | 11 | 0.024868342 | 314.88867 |
| S | L | 12 | 11.12929 | 0.16978283 |
| L | B | 13 | 0.013143006 | 46.296126 |
| L | S | 14 | 0.037070102 | 14.476478 |
| S | S | 15 | 0.0083698983 | 8985.8594 |
| B | L | 16 | 10.712111 | 0.13125843 |
| B | S | 17 | 0.058655804 | 14933.051 |
| L | L | 18 | 0.10420791 | 2.1521405 |
| B | B | 19 | 0.055808166 | 1.0268669 |

Full precision model: [M2L/frozen-model.json](M2L/frozen-model.json). Selection review: [M2L/selection-audit.json](M2L/selection-audit.json). Architecture history: [M2L/architecture-selection.csv](M2L/architecture-selection.csv).

### M2LZ

Background

| target | value |
| --- | --- |
| B | 6.5633759 |
| S | 4.5805797 |
| L | 0.0036215888 |

Exponential

| target | source | mode_index | integrated_mass | tau_seconds |
| --- | --- | --- | --- | --- |
| B | B | 0 | 0.0034800925 | 0.36212804 |
| B | B | 1 | 0.015050036 | 3.7840607 |
| B | B | 2 | 0.015297855 | 100.24983 |
| B | B | 3 | 0.091964837 | 787.8097 |
| B | S | 4 | 0.0010431664 | 9833.4793 |
| S | B | 5 | 0.020821344 | 43.898268 |
| S | S | 6 | 0.016642735 | 7.0197138 |
| S | S | 7 | 0.026515921 | 95.763421 |
| S | S | 8 | 0.025879379 | 2138.9057 |
| S | S | 9 | 0.0030918263 | 933.71202 |
| B | L | 10 | 0.013233169 | 4.7200894 |
| S | L | 11 | 42.942222 | 0.12694288 |
| L | B | 12 | 0.0012204487 | 18.127317 |
| L | L | 13 | 0.22503575 | 3.7740121 |

Diffusion loading

| target | value | tau_seconds | diffusion_index |
| --- | --- | --- | --- |
| B | 2.1692199 | 1.1641252 | 0 |
| S | -0.0041254417 | 1.1641252 | 0 |
| L | -0.2796348 | 1.1641252 | 0 |
| B | 0.0040238205 | 0.8155409 | 1 |
| S | 2.040643 | 0.8155409 | 1 |
| L | 0.044699044 | 0.8155409 | 1 |
| B | 0.462254 | 196.36401 | 2 |
| S | 0.45408445 | 196.36401 | 2 |
| L | 0.10999756 | 196.36401 | 2 |

Full precision model: [M2LZ/frozen-model.json](M2LZ/frozen-model.json). Selection review: [M2LZ/selection-audit.json](M2LZ/selection-audit.json). Architecture history: [M2LZ/architecture-selection.csv](M2LZ/architecture-selection.csv).

Complete architecture history: [model_selection.csv](model_selection.csv). Numerical and initialization reviews are recorded with the frozen selection evidence.
